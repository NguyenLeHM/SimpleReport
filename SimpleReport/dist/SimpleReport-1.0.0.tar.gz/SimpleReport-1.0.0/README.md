# SimpleReport

Python library to interact with the
Supported versions of Python are listed in 

## Installation

pip: (without git)

    pip install SimpleReport
    
Locally:

    python setup.py install

## Usage
import SimpleReport
BuildReport(xmlFile,pdfFile,**kwarg)

## Configuring a timeout

