from scr.SimpleReport import *

BuildReport("C:/Dung/fpdfsample.xml","C:/Dung/Sample.pdf",UserCode='000',UserName='Nguyen Ton Le',FrDate='2022-01-01',ToDate='2022-12-01')


